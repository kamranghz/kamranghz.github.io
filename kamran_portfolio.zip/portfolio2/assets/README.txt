Place photo.jpg and cv.pdf here
